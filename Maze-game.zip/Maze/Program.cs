﻿using Maze.Model;
using System;
using System.Data;
using System.Net.Sockets;
using System.Runtime.CompilerServices;

class Program
{
    static void Main(string[] args)
    {
        // 1. Create a new maze

        int cislo_mapy = 0;


        var maze = LoadMaze(@$"Maps\mapa{cislo_mapy}.map");

        // 2. Create a new player
        PC pc = new PC { X = 0, Y = 0 };
        string vysledok = string.Empty;

        //var gen = new Maze(31,51);
        //maze = gen.Generate();

        // 3. Create a map of the maze
        var mapa = new MapObject[20, 10];
        mapa[0, 3] = new Door(maze, 0, 3, true);

        mapa[19, 7] = new Item
        {
            X = 19,
            Y = 7,
            ItemType = ItemTypeEnum.Key,
            Name = "Kluc",
            Description = "Stary hrdzavy kluc."
        };

        mapa[18, 0] = new Item
        {
            X = 0,
            Y = 18,
            ItemType = ItemTypeEnum.Treasure,
            Name = "slivkove pivo",
            Description = "Stankovo lednicka."
        };

        mapa[3, 0] = new Trap(0, 0);

        mapa[12, 0] = new Trap(18, 7);

        int[] start = new int[] { 0, 0 };
        int[] end = new int[] { maze.GetLength(0) -1, maze.GetLength(1)-1 };
        //int[] current = new int[] { 0, 0 };
        ///            X         X             Y         Y       
        while (true)
        {
            Console.Clear();

            // 4. Print the maze
            PrintMaze(maze, pc.X, pc.Y, end[0], end[1], mapa);

            Console.WriteLine("Use arrow keys to move!");
            Console.WriteLine("Use O to observe.");
            Console.WriteLine("Use P to pickup item.");
            Console.WriteLine("Use U to use item.");
            Console.WriteLine(vysledok);
            vysledok = string.Empty;
            var input = Console.ReadKey();

            // 5. Move the player
            switch (input.Key)
            {
                case ConsoleKey.UpArrow:
                    if (pc.X > 0 && maze[pc.X - 1, pc.Y])
                    {
                        pc.X--;
                    }
                    break;
                case ConsoleKey.DownArrow:
                    if (pc.X < maze.GetLength(0) - 1 && maze[pc.X + 1, pc.Y])
                    {
                        pc.X++;
                    }
                    break;
                case ConsoleKey.LeftArrow:
                    if (pc.Y > 0 && maze[pc.X, pc.Y - 1])
                    {
                        pc.Y--;
                    }
                    break;
                case ConsoleKey.RightArrow:
                    if (pc.Y < maze.GetLength(1) - 1 && maze[pc.X, pc.Y + 1])
                    {
                        pc.Y++;
                    }
                    break;
                case ConsoleKey.O:
                    {
                        vysledok = pc.ObzriSa(mapa);
                    }
                    break;
                case ConsoleKey.P:
                    {
                        vysledok = pc.VezmiPredmet(mapa);
                    }
                    break;
                    // 6. Use item
                case ConsoleKey.U:
                    {                        
                        MapObject obj = (pc.X == 0 ? null : mapa[pc.X-1, pc.Y])
                            ?? (pc.Y == 0 ? null : mapa[pc.X, pc.Y-1])
                            ?? (pc.X == maze.GetLength(0) -1 ? null : mapa[pc.X+1, pc.Y])
                            ?? (pc.Y == maze.GetLength(1) -1 ? null : mapa[pc.X, pc.Y+1]);
                        if (obj == null)
                        {
                            vysledok = "V okoli nie je nic co by si pouzil.";
                            break;
                        }

                        vysledok =  pc.PouziPredmet(obj, maze);

                    }
                    break;
                default:
                    Console.WriteLine("Invalid input.");
                    break;
            }

            // 7. Check if the player has stepped on a trap
            if (mapa[pc.X, pc.Y] is Trap pasca)
            {
                vysledok = pasca.StupilSomNaPascu(pc);
            }

            // 8. Check if the player has reached the end
            if (pc.X == end[0] && pc.Y == end[1])
            {
                var treasure = pc.Inventory.FirstOrDefault(x => x.ItemType == ItemTypeEnum.Treasure);
                if (treasure != null) {
                    cislo_mapy++;
                    maze = LoadMaze(@$"Maps\mapa{cislo_mapy}.map");
                    mapa = new MapObject[maze.GetLength(0), maze.GetLength(1)];
                    pc.X = 0;
                    pc.Y = 0;
                }
                else
                {
                    vysledok = $"Najdi {ItemTypeEnum.Treasure} a pak se vrať.";
                }
            }
        }
        Console.Clear();
        PrintMaze(maze, pc.X, pc.Y, end[0], end[1], mapa);
        Console.WriteLine("You have reached the end of the maze!");
    }

    private static bool[,] LoadMaze(string mapa)
    {
        TextReader subor = new StreamReader(mapa);

        var riadky = subor.ReadToEnd().Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);

        bool[,] bludisko = new bool[riadky.Length, riadky[0].Length];

        for (int i = 0; i < riadky.Length; i++)
        {
            for (int j = 0; j < riadky[i].Length; j++)
            {
                bludisko[i, j] = riadky[i][j] == '1';
            }
        }

        subor.Close();

        return bludisko;
    }


    /// <summary>
    /// Prints the maze to the console.
    /// </summary>
    /// <param name="maze">The maze to print.</param>
    /// <param name="y_act">The actual Y position of the player.</param>
    /// <param name="x_act">The actual X position of the player.</param>
    /// <param name="y_ciel">The Y position of the end.</param>
    /// <param name="x_ciel">The X position of the end.</param>
    /// <param name="mapa">The map of the maze.</param>
    static void PrintMaze(bool[,] maze, int y_act, int x_act, int y_ciel, int x_ciel, MapObject[,] mapa)
    {
        int rows = maze.GetLength(0);
        int cols = maze.GetLength(1);

        // Print the top border
        Console.Write("┌");
        for (int i = 0; i < cols; i++)
        {
            Console.Write("─");
        }
        Console.WriteLine("┐");

        // Print the maze contents
        for (int y = 0; y < rows; y++)
        {
            Console.Write("│");
            for (int x = 0; x < cols; x++)
            {
                if (x==x_act && y==y_act)
                {
                    Console.Write("@");
                    continue;
                }
                if (x==x_ciel && y==y_ciel)
                {
                    Console.Write("!");
                    continue;
                }

                if (mapa[y, x] is Door dvere)
                {
                    if (dvere.Closed)
                        Console.Write("#");
                    else
                        Console.Write(' ');
                    continue;
                }

                if (maze[y, x])
                {
                    if (mapa[y, x] is not null)
                    {
                        if (mapa[y, x] is Item)
                        {
                            Console.Write(".");
                        }

                        if (mapa[y, x] is Trap pasca)
                        {
                            Console.Write(pasca.AktivnaPasca ? " " : "X");
                        }
                    }
                    else
                    {
                        Console.Write(" ");
                    }
                }
                else
                {

                    bool north = y == 0 ? false : maze[y - 1, x];
                    bool south = y == rows - 1 ? false : maze[y + 1, x];
                    bool west = x == 0 ? false : maze[y, x - 1];
                    bool east = x == cols -1 ? false : maze[y, x + 1];

                    if ((!north && !south && west && east) || (!north && south && west && east) || (north && !south && west && east))
                    {
                        Console.Write("│");
                    }
                    else if (north && south && !west && !east)
                    {
                        Console.Write("─");
                    }
                    else if (!north && south && !west && east)
                    {
                        Console.Write("┘");
                    }
                    else if (north && !south && !west && east)
                    {
                        Console.Write("┐");
                    }
                    else if (north && !south && west && !east)
                    {
                        Console.Write("┌");
                    }
                    else if (!north && south && west && !east)
                    {
                        Console.Write("└");
                    }
                    else if (!north && south && !west && !east)
                    {
                        Console.Write("┴");
                    }
                    else if (north && !south && !west && !east)
                    {
                        Console.Write("┬");
                    }
                    else if (!north && !south && !west && east)
                    {
                        Console.Write("┤");
                    }
                    else if (!north && !south && west && !east)
                    {
                        Console.Write("├");

                    }
                    else if (north && south && !west && east)
                    {
                        Console.Write("─");
                    }
                    else if (north && south && west && !east)
                    {
                        Console.Write("─");
                    }
                    else
                    {
                        Console.Write("┼");
                    }
                }
            }
            Console.WriteLine("│");
        }

        // Print the bottom border
        Console.Write("└");
        for (int i = 0; i < cols; i++)
        {
            Console.Write("─");
        }
        Console.WriteLine("┘");
    }

    private static void SaveMaze(bool[,] bludisko)
    {
        Console.Write("Zadaj nazov suboru: ");
        var nazov = Console.ReadLine();

        TextWriter subor = new StreamWriter(nazov);

        for (int i = 0; i < bludisko.GetLength(0); i++)
        {
            for (int j = 0; j < bludisko.GetLength(1); j++)
            {
                subor.Write(bludisko[i, j] ? "1" : "0");
            }
            subor.WriteLine();
        }

        subor.Close();
    }
}
