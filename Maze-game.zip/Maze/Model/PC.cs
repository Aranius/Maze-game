﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Maze.Model
{
    public class PC : Creature
    {
        public List<Item> Inventory { get; set; }

        public PC()
        {
            ObjectType = ObjectTypeEnum.PC;
            Inventory = new List<Item>();
        }

        public string VezmiPredmet(MapObject[,] mapa)
        {
            if (mapa[X, Y] is Item item)
            {
                Inventory.Add(item);
                mapa[X, Y] = null;

                return $"Zobral som predmet {item.Name} do svojho inventara.";
            }

            return "Nevidim tu nic co by som mohol zobrat";
        }

        public string ObzriSa(MapObject[,] mapa)
        {
            if (mapa[X, Y] is Item item)
            {
                return $"Vidis na zemi: {item.Name}";
            }

            return "Nic nevidis na zemi!";
        }

        public string PouziPredmet(MapObject obj, bool[,] maze)
        {
            if (obj is Door door)
            {
                if (door.Locked)
                {
                    return door.Odomkni(this);
                }

                if (door.Closed)
                {
                    return door.Otvor(maze);
                }
            }

            return "Nie je tu nic na pouzitie";
        }
    }
}
