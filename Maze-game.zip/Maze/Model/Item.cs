﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Maze.Model
{
    public class Item : MapObject
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public ItemTypeEnum ItemType { get; set; }

        public Item()
        {
            ObjectType = ObjectTypeEnum.Item;
        }

    }

    public enum ItemTypeEnum
    {
        Key,
        Weapon,
        Shield,
        Armor,
        Potion,
        Treasure,
    }
}
