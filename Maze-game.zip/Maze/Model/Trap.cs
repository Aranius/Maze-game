﻿using Maze.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maze.Model
{
    internal class Trap : MapObject, ITrap
    {
        public int TeleportaceX { get; set; }
        public int TeleportaceY { get; set; }
        public bool AktivnaPasca { get; set; }

        public Trap(int x, int y)
        {
            TeleportaceX = x;
            TeleportaceY = y;
            ObjectType = ObjectTypeEnum.Trap;
            AktivnaPasca = true;
        }

        public string StupilSomNaPascu(PC pc)
        {
            if (AktivnaPasca)
            {
                pc.X = TeleportaceX;
                pc.Y = TeleportaceY;
                AktivnaPasca = false;

                return "Vstupil si na pascu";
            }

            return "Preskocil si pascu";
        }
    }
}
