﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maze.Model
{
    internal class Door : MapObject
    {
        public bool Locked { get; set; }
        public bool Closed { get; set; } = true;

        public Door(bool[,] maze, int x, int y, bool locked = false)
        {
            Locked = locked;
            X = x;
            Y = y;
            maze[x, y] = false;
            ObjectType = ObjectTypeEnum.Door;
        }

        public string Odomkni(PC pc)
        {
            var najdeny_kluc = pc.Inventory.FirstOrDefault(x => x.ItemType == ItemTypeEnum.Key);
            if (najdeny_kluc != null)
            {
                Locked = false;
                pc.Inventory.Remove(najdeny_kluc);
                return "Odomkol si uspesne dvere";
            }
            else
            {
                return "Nemas ziadny kluc!";
            }
        }

        public string Otvor(bool[,] maze)
        {
            if (!Locked)
            {
                maze[X, Y] = true;
                Closed = false;
                return "Otvoril si dvere";
            }
            else
            {
                return "Dvere su zamknute";
            }
        }
    }
}
